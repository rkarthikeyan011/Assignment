﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FizzBuzz
{

    public static class Constants
    {
        public const string Fizz= "Fizz";
        public const string Buzz = "Buzz";
        public const string FizzBuzz = "FizzBuzz";
    }

    public static class FizzBuzz
    {
        public static string CheckFizzBuzz(int i)
        {
            if (i == 0)
            {
                return i.ToString();
            }
            return i % 15 == 0 ? Constants.FizzBuzz : (i % 3 == 0 ? Constants.Fizz : i % 5 == 0 ? Constants.Buzz : i.ToString());
        }
    }
}
