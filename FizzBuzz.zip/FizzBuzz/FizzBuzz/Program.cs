﻿using System;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(FizzBuzz.CheckFizzBuzz(3));
            Console.Read();
        }

       
    }
}
