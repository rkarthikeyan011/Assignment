using System;
using Xunit;
using FizzBuzz;

namespace FizzBuzz.Test
{
    public class FizzBuzzTest
    {
        [Theory]
        [InlineData(3, Constants.Fizz)]
        [InlineData(15, Constants.FizzBuzz)]
        [InlineData(-2002, "-2002")]
        [InlineData(0, "0")]
        [InlineData(100, Constants.Buzz)]
        public void Check_FizzBuzz_Based_on_Integer(int i, string expected)
        {
            string actual = FizzBuzz.CheckFizzBuzz(i);
            Assert.Equal(expected, actual);
        }
    }
}
