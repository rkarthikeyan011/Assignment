﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleLedger
{
    public class CashBook
    {
        private double m_Balance;

        private List<Transaction> m_transactions=new List<Transaction>();

        public List<Transaction> Transactions
        {
            get
            {
                return m_transactions;
            }
        }

        public double Balance
        {
            get
            {
                return m_Balance;
            }
        }
        private CashBook()
        {
            
        }
        private static CashBook instance = null;
        public static CashBook Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CashBook();
                }
                return instance;
            }
        }

        

        public void OpeningBalance()
        {
            //Assuming it fectch from database for now hardcode
            m_Balance = 5000;
        }

        public void AddEntry(Transaction transaction)
        {
            transaction.PrevousBalance = m_Balance;
            if (transaction.Type == "Credit")
            {
                m_Balance += transaction.Value;
            }
            else
            {
                m_Balance -= transaction.Value;
            }
            m_transactions.Add(transaction);
        }
    }
}
