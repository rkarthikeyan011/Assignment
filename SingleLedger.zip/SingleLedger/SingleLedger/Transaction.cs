﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleLedger
{
    public class Transaction
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public double Value { get; set; }
        public DateTime DateTime { get; set; }
        public string Notes { get; set; }
        public string Type { get; set; }
        public double PrevousBalance { get; set; }
    }
}
